#include "Database.h"

Database::Database(std::string trucPourData)
{
    //ctor
}

Database::~Database()
{
    //dtor
}
